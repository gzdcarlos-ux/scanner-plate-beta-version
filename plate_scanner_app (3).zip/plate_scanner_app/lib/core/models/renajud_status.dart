/// De onde veio a resposta — útil para auditoria/debug, nunca exibido
/// como "dado extra" ao usuário final.
enum RenajudSource { local, remote, mock, notFound, errorFallback }

/// Resultado ÚNICO e minimalista de uma consulta.
///
/// Por design, este modelo NUNCA carrega marca/modelo/ano/proprietário —
/// apenas o necessário para responder a pergunta booleana. Isso é
/// intencional (minimização de dados / LGPD): qualquer campo extra que
/// um provider real devolva deve ser descartado ANTES de chegar aqui
/// (veja `RemoteRenajudProvider._mapResponseToStatus`).
class RenajudStatus {
  final String plate;
  final bool? hasRestriction; // null = não foi possível determinar (erro/indefinido)
  final String? observation;  // observação opcional vinda da planilha local
  final RenajudSource source;
  final DateTime checkedAt;

  const RenajudStatus({
    required this.plate,
    required this.hasRestriction,
    required this.source,
    required this.checkedAt,
    this.observation,
  });

  bool get isKnown => hasRestriction != null;
  bool get isRestricted => hasRestriction == true;

  factory RenajudStatus.notFound(String plate) => RenajudStatus(
        plate: plate,
        hasRestriction: null,
        source: RenajudSource.notFound,
        checkedAt: DateTime.now(),
      );

  factory RenajudStatus.error(String plate) => RenajudStatus(
        plate: plate,
        hasRestriction: null,
        source: RenajudSource.errorFallback,
        checkedAt: DateTime.now(),
      );
}
